--disp all employee record using cursor
set serveroutput on
declare
	cursor S1 IS select * from sales_data;
	x sales_data%ROWTYPE;
	ts number;
	comm number;
begin
	open S1;
loop
	fetch S1 into x;
exit when S1%NOTFOUND;
	ts:= x.Sales1 + x.Sales2;
	dbms_output.put_line('Your Total Sale Is: '||ts);
if ts > 0 and ts < 15000
then
	comm := ts * 0.05;
	dbms_output.put_line('Your Total Commission Is: '||comm);
elsif ts >= 15000 and ts <= 30000
then
	comm := ts * 0.10;
	dbms_output.put_line('Your Total Commission Is: '||comm);
else 
	comm := ts * 0.15;
	dbms_output.put_line('Your Total Commission Is: '||comm);
end if;
end loop;
	close S1;
end;
/