--disp first record using explict cursor
set serveroutput on
declare
	cursor c1 IS select rlno, name, division from stud;
	rl stud.rlno%TYPE;
	nm stud.name%TYPE;
	div stud.division%TYPE;
begin
	open c1;
--loop
	fetch c1 into rl,nm,div;
--exit when c2%NOTFOUND;
	dbms_output.put_line('Roll No: '||rl);
	dbms_output.put_line('Name: '||nm);
	dbms_output.put_line('Division: '||div);
--end loop;
	close c1;
end;
/