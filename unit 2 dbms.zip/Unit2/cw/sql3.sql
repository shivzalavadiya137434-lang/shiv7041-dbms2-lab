--disp all employee record using cursor
set serveroutput on
declare
	cursor c3 IS select * from employee;
	x employee%ROWTYPE;
begin
	open c3;
loop
	fetch c3 into x;
exit when c3%NOTFOUND;
	dbms_output.put_line('EID: '||x.eid);
	dbms_output.put_line('EName: '||x.ename);
	dbms_output.put_line('Deptno: '||x.deptno);
	dbms_output.put_line('Deptname: '||x.deptname);
	dbms_output.put_line('Gen: '||x.gender);
	dbms_output.put_line('Age: '||x.age);
	dbms_output.put_line('Basic Salary: '||x.basicsal);
	dbms_output.put_line('Gross Salary: '||x.gross_salary);
end loop;
	close c3;
end;
/