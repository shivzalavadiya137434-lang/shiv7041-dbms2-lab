--Create table of product with proid, proname and proprice and use cursor for loop
set serveroutput on
declare
	i number;
begin
for i IN (select proid, pro_name, pro_price from product)
loop
	dbms_output.put_line('Product ID is: '|| i.proid);
	dbms_output.put_line('Product Name is: '|| i.pro_name);
	dbms_output.put_line('Product Price is: '|| i.pro_price);
end loop;
end;
/