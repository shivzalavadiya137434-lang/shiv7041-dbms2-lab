--disp all record using explict cursor
set serveroutput on
declare
	cursor c2 IS select rlno, name, division from stud;
	rl stud.rlno%TYPE;
	nm stud.name%TYPE;
	div stud.division%TYPE;
begin
	open c2;
loop
	fetch c2 into rl,nm,div;
exit when c2%NOTFOUND;
	dbms_output.put_line('Roll No: '||rl);
	dbms_output.put_line('Name: '||nm);
	dbms_output.put_line('Division: '||div);
end loop;
	close c2;
end;
/