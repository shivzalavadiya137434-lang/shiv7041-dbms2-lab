--Program to print Name, Address1, Address2, City, State

set serveroutput on

declare
	Name char(15):='&Name';
	Address1 char(15):='&Address1';
	Address2 char(15):='&Address2';
	City char(15):='&City';
	State char(15):='&State';

begin

	dbms_output.put_line('My Name is '||Name);
	dbms_output.put_line('My House Name is '||Address1);
	dbms_output.put_line('Which is nearby to '||Address2);
	dbms_output.put_line('City I live is '||City);
	dbms_output.put_line('And the state is '||State);

end;
/