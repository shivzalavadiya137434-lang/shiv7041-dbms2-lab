--Print 1-5 using loop
set serveroutput on
declare
	i number:=1;
begin
loop
	dbms_output.put_line(i);
	i:= i + 1;
	Exit when (i>5);
end loop;
end;
/