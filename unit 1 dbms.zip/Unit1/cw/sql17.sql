--Print 100,90,80,....,0
set serverout on
declare
	i NUMBER:=100;
begin
loop
	dbms_output.put_line(i);
	i:=i-10;
	exit when  (i<0);
end loop;
end;
/