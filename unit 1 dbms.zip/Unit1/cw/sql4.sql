--Print course, semester
set serveroutput on

declare
	Course char(20):='BCA';
	Semester number(20):='3';

begin

	dbms_output.put_line(course);
	dbms_output.put_line(semester);

end;
/