--Program to print hello welcome

set serveroutput on

begin

	dbms_output.put_line('Hello');
	dbms_output.put_line('Welcome');

end;
/