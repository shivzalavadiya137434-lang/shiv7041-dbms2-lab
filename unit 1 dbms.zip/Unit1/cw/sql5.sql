--Print 2 sub and 2 topics

set serveroutput on

begin

	dbms_output.put_line('Subject:- Advance DBMS');
	dbms_output.put_line('Topic:- Introduction of dbms');
	dbms_output.put_line('Topic:- DDL Commands');
	dbms_output.put_line('Subject:- JAVA');
	dbms_output.put_line('Topic:- Introduction of JAVA');
	dbms_output.put_line('Topic:- Java History');

end;
/