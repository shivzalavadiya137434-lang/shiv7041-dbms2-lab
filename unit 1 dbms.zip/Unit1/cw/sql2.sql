--Program to print Name, Address1, Address2, City, Pincode, State

set serveroutput on

begin

	dbms_output.put_line('Shiv');
	dbms_output.put_line('Ashutosh');
	dbms_output.put_line('University Road');
	dbms_output.put_line('Rajkot');
	dbms_output.put_line('360005');
	dbms_output.put_line('Gujarat');

end;
/