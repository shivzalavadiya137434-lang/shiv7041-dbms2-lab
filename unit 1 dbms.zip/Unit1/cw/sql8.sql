--Program to update result using simple if

set serveroutput on

declare
	rl number(10):=&rl;
	p number(8,2);
begin
	select per into p from marks where rlno=rl;
if p>=40
then 
	update marks set result = 'pass' where rlno=rl;
	commit;
dbms_output.put_line('Result Updated');

end if;
end;
/