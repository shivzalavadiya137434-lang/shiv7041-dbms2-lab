--Print the square of n number using loop
set serveroutput on
declare
	i number:=1;
	n number:=10;
begin
loop
	dbms_output.put_line(i*i);
	i:=i+1;
	Exit when (i>n);
end loop;
end;
/