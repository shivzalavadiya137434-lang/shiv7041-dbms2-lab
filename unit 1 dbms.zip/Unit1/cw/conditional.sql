--conditional statement
set serveroutput on
declare

	no number(10):=&no;
	nm char(20);
	pr number(8,2);
	res char(10);

begin

	select NAME, PER, RESULT into nm,pr,res from marks where rlno=no;
	dbms_output.put_line('Roll No : '||no);
	dbms_output.put_line('Name : '||nm);
	dbms_output.put_line('Percentage : '||pr);
	dbms_output.put_line('Result : '||res);

if pr >33 then

 dbms_output.put_line('Result = pass');

else 

dbms_output.put_line('Result = Fail');

end if;

commit;

end;
/