--Print series of odd number
set serveroutput on
declare
	i number:=1;
	n number:=&n;
begin

loop
	dbms_output.put_line(i);
	i:=i+2;
	exit when (i>n);
end loop;
end;
/