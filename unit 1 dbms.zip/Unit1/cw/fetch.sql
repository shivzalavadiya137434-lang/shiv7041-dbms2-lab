--fetch the emp details
set serveroutput on;
declare
	no  NUMBER(10):=&rlno;
	nm  CHAR(20);
	per NUMBER(8,2);
	res CHAR(10);
begin

	select NAME, PER, RESULT into nm,per,res from marks where rlno=no;
	dbms_output.put_line('Roll No : '||no);
	dbms_output.put_line('Name : '||nm);
	dbms_output.put_line('Percentage : '||per);
	dbms_output.put_line('Result : '||res);


end;
/