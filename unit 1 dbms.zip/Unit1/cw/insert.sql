--insert emp details
set serveroutput on;
declare
	eno  NUMBER(5):=&eno;
	enm  CHAR(20):='&enm';
	dep NUMBER(5):=&dep;
	sal NUMBER(7):=&sal;
begin

	INSERT INTO EMP VALUES(eno,enm,dep,sal);
	commit;
	dbms_output.put_line('Your records are inserted.');

end;
/