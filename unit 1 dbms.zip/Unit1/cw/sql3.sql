--Print name, surname and age

set serveroutput on

declare
	name char(20):='Shivraj';
	surname char(20):='Desai';
	age number(5):=22;

begin

	dbms_output.put_line(name);
	dbms_output.put_line(surname);
	dbms_output.put_line(age);

end;
/