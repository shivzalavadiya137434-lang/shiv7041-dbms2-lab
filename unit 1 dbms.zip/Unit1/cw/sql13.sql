--Print 100,90,80,....,0
set serverout on
declare
	i NUMBER:=100;
begin
while i>=0
loop
	dbms_output.put_line(i);
	i:=i-10;
end loop;
end;
/