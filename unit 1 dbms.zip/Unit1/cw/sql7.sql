--program to accept 2 numbers and print +,-,*,/
set serveroutput on
declare
	no1 number:=&no1;
	no2 number:=&no2;
	s number;
	m number;
	m1 number;
	d number;
begin
	s:=no1 + no2;
	dbms_output.put_line('sum of no1 + no2 = ' ||s);
	m:=no1 - no2;
	dbms_output.put_line('subtraction of no1 - no2 = ' ||m);
	m1:=no1 * no2;
	dbms_output.put_line('multiplication of no1 * no2 = ' ||m1);
	d:=no1 / no2;
	dbms_output.put_line('division of no1 / no2 = ' ||d);
end;
/