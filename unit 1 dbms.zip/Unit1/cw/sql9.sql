--If-else Demo

Set serveroutput on
declare

	sr number(3):=&sr;
	s number(5);
begin

	select sales  into s from sdata where sr_no=sr;
if s>=10000 and s<=30000
then

	update sdata set commission=(s*0.10) where sr_no=sr;
	commit;

else
	update sdata set commission=0 where sr_no=sr;
	commit;
end if;
	dbms_output.put_line('Record Updated');
end;
/